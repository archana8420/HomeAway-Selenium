package pageObject;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class homePage {

	private static WebElement Element = null; 
	
	public static WebElement txtSearch(WebDriver driver)
	{
		Element = driver.findElement(By.xpath(".//*[@value='Search Products']"));
		return Element;
	}
	
	public static WebElement btnBuy(WebDriver driver)
	{
		Element = driver.findElement(By.name("Buy"));
		return Element;
	}
	
	public static WebElement btnCart(WebDriver driver)
	{
		Element = driver.findElement(By.linkText("Go to Checkout"));
		return Element;
	}
	
	public static WebElement btnContShopping(WebDriver driver)
	{
		Element = driver.findElement(By.linkText("Continue Shopping"));
		return Element;
	}
	
	public static WebElement lnkMyAccount(WebDriver driver)
	{
		Element = driver.findElement(By.xpath(".//*[@title='My Account']"));
		return Element;
	}

	public static WebElement txtUsername(WebDriver driver)
	{
		Element = driver.findElement(By.id("log"));
		return Element;
	}
	
	public static WebElement txtPassword(WebDriver driver)
	{
		Element = driver.findElement(By.id("pwd"));
		return Element;
	}
	
	public static WebElement btnLogin(WebDriver driver)
	{
		Element = driver.findElement(By.id("login"));
		return Element;
	}
	
}
