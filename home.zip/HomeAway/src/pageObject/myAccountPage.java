package pageObject;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class myAccountPage {

private static WebElement Element = null; 
	
	public static WebElement lnkProfile(WebDriver driver)
	{
		Element = driver.findElement(By.linkText("Howdy, amurthy"));
		return Element;
	}
	
	public static WebElement txtFirstName(WebDriver driver)
	{
		Element = driver.findElement(By.id("first_name"));
		return Element;
	}
	
	public static WebElement txtLastName(WebDriver driver)
	{
		Element = driver.findElement(By.id("last_name"));
		return Element;
	}
	
	public static WebElement btnUpdate(WebDriver driver)
	{
		Element = driver.findElement(By.xpath(".//*[@value='Update Profile']"));
		return Element;
	}
	
	public static WebElement lnkLogout(WebDriver driver)
	{
		Element = driver.findElement(By.xpath(".//*[@id='wp-admin-bar-logout']/a"));
		return Element;
	}
	
}
