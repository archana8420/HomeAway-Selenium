package pageObject;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class checkoutPage {

	private static WebElement Element = null; 
	
	public static WebElement btnContinue(WebDriver driver)
	{
		Element = driver.findElement(By.xpath(".//*[@id='checkout_page_container']/div[1]/a/span"));
		return Element;
	}
	
	public static WebElement txtQuantity(WebDriver driver)
	{
		Element = driver.findElement(By.name("quantity"));
		return Element;
	}
	
	public static WebElement btnUpdate(WebDriver driver)
	{
		Element = driver.findElement(By.xpath(".//*[@value='Update']"));
		return Element;
	}
	
	public static WebElement btnRemove(WebDriver driver)
	{
		Element = driver.findElement(By.xpath(".//*[@value='Remove']"));
		return Element;
	}
	
	public static WebElement drpdwnCountry(WebDriver driver)
	{
		Element = driver.findElement(By.id("current_country"));
		return Element;
	}
	
	public static WebElement btnCalculate(WebDriver driver)
	{
		Element = driver.findElement(By.name("wpsc_submit_zipcode"));
		return Element;
	}

	public static WebElement txtEmail(WebDriver driver)
	{
		Element = driver.findElement(By.id("wpsc_checkout_form_9"));
		return Element;
	}

	public static WebElement txtFirstNm(WebDriver driver)
	{
		Element = driver.findElement(By.id("wpsc_checkout_form_2"));
		return Element;
	}
	
	public static WebElement txtLastNm(WebDriver driver)
	{
		Element = driver.findElement(By.id("wpsc_checkout_form_3" ));
		return Element;
	}
	
	public static WebElement txtAddress(WebDriver driver)
	{
		Element = driver.findElement(By.id("wpsc_checkout_form_4"));
		return Element;
	}
	

	public static WebElement txtCity(WebDriver driver)
	{
		Element = driver.findElement(By.id("wpsc_checkout_form_5"));
		return Element;
	}
	
	public static WebElement txtState(WebDriver driver)
	{
		Element = driver.findElement(By.id("wpsc_checkout_form_6" ));
		return Element;
	}
	
	public static WebElement txtCountry(WebDriver driver)
	{
		Element = driver.findElement(By.id("wpsc_checkout_form_7"));
		return Element;
	}
	
	public static WebElement txtPhone(WebDriver driver)
	{
		Element = driver.findElement(By.id("wpsc_checkout_form_18"));
		return Element;
	}
	
	public static WebElement chkbxShippingAdd(WebDriver driver)
	{
		Element = driver.findElement(By.id("shippingSameBilling"));
		return Element;
	}
	public static WebElement btnPurchase(WebDriver driver)
	{
		Element = driver.findElement(By.xpath(".//*[@value='Purchase']"));
		return Element;
	}
	
}