package automationFramework;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.Assert;

import pageObject.checkoutPage;
import pageObject.homePage;

public class iPhonePurchase {

	 private static WebDriver driver = null;
	 
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//Variables used below
		Double shippingCost = 12.00;
		
		//Initiate Driver
		driver = new FirefoxDriver();
		driver.manage().timeouts().implicitlyWait(90, TimeUnit.SECONDS);
		driver.get("http://store.demoqa.com");
		driver.manage().window().maximize();
		
		//Page Objects will be referred now
		
		homePage.txtSearch(driver).sendKeys("iPhone 4S Black");
		homePage.txtSearch(driver).submit();
		String expText = driver.findElement(By.xpath(".//*[@class='currentprice']")).getText();
		System.out.println("The expected cost before shipping is : " + expText);
		homePage.btnBuy(driver).click();
		homePage.btnCart(driver).click();
		
		//Shopping Cart
		String quantity = checkoutPage.txtQuantity(driver).getText();
		System.out.println("Quantity is : " + quantity);
		String actText = null;
		if(quantity.equals("1")){
			actText = driver.findElement(By.xpath(".//*[@class='pricedisplay']")).getText();
			
		}else {
			checkoutPage.txtQuantity(driver).clear();
			checkoutPage.txtQuantity(driver).sendKeys("01");
			checkoutPage.btnUpdate(driver).click();
			actText = driver.findElement(By.xpath(".//*[@class='pricedisplay']")).getText();
		}
		
		System.out.println("The actual cost before shipping is : " + actText);
		
		//First Validation of the price in the cart
		Assert.assertEquals(actText, expText);
		System.out.println("First validation passed of the price in the cart Passed");
		checkoutPage.btnContinue(driver).click();
		checkoutPage.drpdwnCountry(driver).sendKeys("USA");
		checkoutPage.btnCalculate(driver).click();
		checkoutPage.txtFirstNm(driver).sendKeys("John");
		checkoutPage.txtLastNm(driver).sendKeys("Doe");
		checkoutPage.txtEmail(driver).sendKeys("test@gmail.com");
		checkoutPage.txtAddress(driver).sendKeys("1st st apt 101");
		checkoutPage.txtCity(driver).sendKeys("Redmond");
		checkoutPage.txtState(driver).sendKeys("WA");
		checkoutPage.txtCountry(driver).sendKeys("USA");
		checkoutPage.txtPhone(driver).sendKeys("9876054321");
		checkoutPage.chkbxShippingAdd(driver).click();
		//Retrieving Total Cost including shipping
		String act2Text = driver.findElement(By.xpath(".//*[@id='checkout_total']/span")).getText();
		act2Text = act2Text.substring(1);
		//conversion to Double
		Double actCost = Double.parseDouble(act2Text);
		System.out.println("The actual cost including shipping  is " + actCost);
		
		//Adding shipping cost to product price to compare against final cost
		expText = expText.substring(1);
		Double expCost = Double.parseDouble(expText);
		expCost = expCost + shippingCost;
		System.out.println("The expected cost including shipping  is " + expCost);
		
		//Final Validation of total cost
		Assert.assertEquals(actCost, expCost);
		System.out.println("Test Case Passed the values matched");
		checkoutPage.btnPurchase(driver).click();
		
		driver.close();
		driver.quit();
	}

}
