package automationFramework;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.Assert;

import pageObject.checkoutPage;
import pageObject.homePage;

public class emptyShoppingCart {

	 private static WebDriver driver = null;
	 
	public static void main(String[] args) {
		
		//Initiate Driver
		driver = new FirefoxDriver();
		driver.manage().timeouts().implicitlyWait(90, TimeUnit.SECONDS);
		driver.get("http://store.demoqa.com");
		driver.manage().window().maximize();
		
		//Page Objects will be referred now
		//Searching and adding a product
		homePage.txtSearch(driver).sendKeys("iPhone 4S Black");
		homePage.txtSearch(driver).submit();
		homePage.btnBuy(driver).click();
		homePage.btnCart(driver).click();

		//Removing the products from shopping cart
		checkoutPage.btnRemove(driver).click();
 
		//Validating the message
		String actText = driver.findElement(By.xpath(".//*[@id='post-29']/div")).getText();
		Assert.assertEquals(actText, "Oops, there is nothing in your cart.");
		System.out.println("The appropriate message was displayed when the cart is empty");
	}
	
}

		
