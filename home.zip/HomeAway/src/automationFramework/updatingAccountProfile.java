package automationFramework;

import java.util.concurrent.TimeUnit;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;
import org.testng.Assert;

import pageObject.homePage;
import pageObject.myAccountPage;

public class updatingAccountProfile {

	 private static WebDriver driver = null;
	 
	public static void main(String[] args) {
		
		//Variables
		 String user = "amurthy";
		 String password = "Abcd1234$5678";
		 String frstName = "John";
		 String lastname = "Doe";
		 String Value = "value";
		 
		//Initiate Driver
		driver = new FirefoxDriver();
		driver.manage().timeouts().implicitlyWait(90, TimeUnit.SECONDS);
		driver.get("http://store.demoqa.com");
		driver.manage().window().maximize();
		
		//Page Objects will be referred now
		//Login to Website
		login(user, password);
				
		//Update Profile 
		updateProfile(frstName, lastname);
		
		//ReLogin
		//driver.close();
		driver.get("http://store.demoqa.com");
		driver.manage().window().maximize();
		login(user, password);
		
		//Validation is information is saved
		myAccountPage.lnkProfile(driver).click();
		String actFrstName = myAccountPage.txtFirstName(driver).getAttribute(Value);
		String actLastName = myAccountPage.txtLastName(driver).getAttribute(Value);
		Assert.assertEquals(actFrstName, frstName);
		Assert.assertEquals(actLastName, lastname);
		System.out.println("The test case has passed");
		System.out.println("Expected First Name is " + frstName);
		System.out.println("Actual First Name is " + actFrstName);
		System.out.println("Expected First Name is " + lastname);
		System.out.println("Actual First Name is " + actLastName);
		driver.close();
		driver.quit();
	}

	private static void updateProfile(String frstName, String lastname) {
		
		myAccountPage.lnkProfile(driver).click();
		myAccountPage.txtFirstName(driver).clear();
		myAccountPage.txtLastName(driver).clear();
		myAccountPage.txtFirstName(driver).sendKeys(frstName);
		myAccountPage.txtLastName(driver).sendKeys(lastname);
		myAccountPage.btnUpdate(driver).click();
		
		   WebElement menuHoverLink = myAccountPage.lnkProfile(driver);
		   Actions action = new Actions(driver);
		   action.moveToElement(menuHoverLink).build().perform();
		   myAccountPage.lnkLogout(driver).click(); 
	}

	private static void login(String user, String password) {
		homePage.lnkMyAccount(driver).click();
		homePage.txtUsername(driver).sendKeys(user);
		homePage.txtPassword(driver).sendKeys(password);
		homePage.btnLogin(driver).click();
		
		
	}
}
